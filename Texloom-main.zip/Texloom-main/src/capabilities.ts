import type {Bundle, PaintItem} from './schema.js';

/** Versioned renderer vocabulary. Semantic operations are evaluated upstream. */
export const VECTOR_2D_FEATURES = [
  'path.2d', 'primitive.2d', 'tex.outlines', 'field.scalar-grid.2d',
  'transform.affine.2d', 'paint.clip', 'paint.opacity', 'paint.dash',
  'paint.current-color', 'path.arrowheads',
] as const;
export const SPATIAL_3D_FEATURES=['mesh.triangles.3d','transform.affine.3d','camera.affine.3d',
  'camera.projection.3d','material.unlit.3d','material.wireframe.3d','clip.planes.3d','overlay.tex.3d','animation.transform.3d','surface.parametric.3d',
  'curve.polyline.3d','frame.transport.3d','constraint.curve-follow.3d',
  'attribute.mesh.3d','attribute.domain-transfer.3d','material.color-attribute.3d','instance.mesh.3d','instance.realize.3d',
  'field.visualization.3d','field.normal-displacement.3d','field.vector-arrows.3d','field.sampled.3d','bake.temporal.3d'] as const;
export type RenderFeature = typeof VECTOR_2D_FEATURES[number]|typeof SPATIAL_3D_FEATURES[number];
export interface CapabilityProfile {
  readonly id: string;
  readonly contract: 'texloom-render/1';
  readonly features: readonly string[];
}
export const SVG_2D_PROFILE: CapabilityProfile = Object.freeze({
  id: 'texloom.svg2d/1', contract: 'texloom-render/1', features: Object.freeze([...VECTOR_2D_FEATURES]),
});
export const CANVAS_2D_PROFILE: CapabilityProfile = Object.freeze({
  id: 'texloom.canvas2d/1', contract: 'texloom-render/1', features: Object.freeze([...VECTOR_2D_FEATURES]),
});
/** Core numeric evaluator only; this profile does not promise rasterization or projection. */
export const NUMERIC_3D_PROFILE: CapabilityProfile = Object.freeze({
  id:'texloom.numeric3d/1',contract:'texloom-render/1',features:Object.freeze([...VECTOR_2D_FEATURES,...SPATIAL_3D_FEATURES]),
});
export const GPU_3D_PROFILE: CapabilityProfile = Object.freeze({
  id:'texloom.gpu3d/1',contract:'texloom-render/1',features:Object.freeze([...VECTOR_2D_FEATURES,...SPATIAL_3D_FEATURES]),
});
export interface CapabilityReport {
  profile: string; compatible: boolean; required: string[]; unsupported: string[];
}
/** No implicit flattening, dropping, or selection of a lossy fallback. */
export function checkCapabilities(required: readonly string[], profile: CapabilityProfile): CapabilityReport {
  if (profile.contract !== 'texloom-render/1') throw new Error(`Unsupported renderer contract: ${profile.contract}`);
  const normalized = [...new Set(required)].sort();
  const unsupported = normalized.filter(feature => !profile.features.includes(feature));
  return {profile: profile.id, compatible: unsupported.length === 0, required: normalized, unsupported};
}
export function requireCapabilities(required: readonly string[], profile: CapabilityProfile): CapabilityReport {
  const report = checkCapabilities(required, profile);
  if (!report.compatible) throw new Error(`RENDER_CAPABILITY: ${profile.id} cannot render ${report.unsupported.join(', ')}`);
  return report;
}

/** Call after bundle validation; inventories every resource, even a hidden one. */
export function sceneFeatures(bundle: Bundle): RenderFeature[] {
  const features = new Set<RenderFeature>();
  const paint = (item: {style?: PaintItem['style']; clip?: unknown; transform?: unknown}) => {
    if (item.clip) features.add('paint.clip');
    if (item.transform) features.add('transform.affine.2d');
    const s = item.style;
    if (s?.opacity !== undefined || s?.fillOpacity !== undefined || s?.strokeOpacity !== undefined) features.add('paint.opacity');
    if (s?.dash?.length) features.add('paint.dash');
    if (s?.fill === 'currentColor' || s?.stroke === 'currentColor') features.add('paint.current-color');
  };
  const vector = (items: PaintItem[]) => {
    for (const item of items) {
      paint(item);
      if (item.kind === 'path') features.add('path.2d');
      if (item.children) vector(item.children);
    }
  };
  for (const node of bundle.nodes) {
    paint(node);
    if (node.kind === 'path') {
      features.add('path.2d');
      if (node.arrowStart || node.arrowEnd || node.arrows) features.add('path.arrowheads');
    } else if (node.kind === 'tex') features.add('tex.outlines');
    else if (node.kind === 'field') features.add('field.scalar-grid.2d');
    else if (node.kind !== 'group') features.add('primitive.2d');
  }
  for (const resource of Object.values(bundle.resources)) {
    if (resource.kind === 'vector') vector(resource.items);
    if (resource.kind === 'mesh') features.add('mesh.triangles.3d');
    if (resource.kind === 'curve3d') features.add('curve.polyline.3d');
    if (resource.kind === 'mesh'&&resource.attributes)features.add('attribute.mesh.3d');
  }
  if(bundle.space3d){
    features.add('transform.affine.3d');
    if(bundle.space3d.camera)features.add('camera.affine.3d');
    if(bundle.space3d.nodes.some(n=>n.kind==='mesh'))features.add('mesh.triangles.3d');
    if(bundle.space3d.nodes.some(n=>n.kind==='curve'))features.add('curve.polyline.3d');
    if(bundle.space3d.camera?.projection)features.add('camera.projection.3d');
    if(bundle.space3d.nodes.some(n=>(n.kind==='mesh'||n.kind==='instances')&&n.material))features.add('material.unlit.3d');
    if(bundle.space3d.nodes.some(n=>(n.kind==='mesh'||n.kind==='instances')&&n.material?.wireframe))features.add('material.wireframe.3d');
    if(bundle.space3d.nodes.some(n=>(n.kind==='mesh'||n.kind==='instances')&&n.material?.colorAttribute))features.add('material.color-attribute.3d');
    if(bundle.space3d.clippingPlanes?.length)features.add('clip.planes.3d');
    if(bundle.space3d.overlays?.length)features.add('overlay.tex.3d');
    if(bundle.space3d.tracks?.length)features.add('animation.transform.3d');
  }
  if(bundle.surfaces?.operations.length){features.add('mesh.triangles.3d');features.add('surface.parametric.3d');}
  if(bundle.curves3d?.operations.length){features.add('curve.polyline.3d');features.add('frame.transport.3d');}
  if(bundle.curves3d?.followers.length)features.add('constraint.curve-follow.3d');
  if(bundle.meshAttributes?.operations.length)features.add('attribute.mesh.3d');
  if(bundle.meshAttributes?.operations.some(o=>o.steps.some(s=>s.kind==='transfer')))features.add('attribute.domain-transfer.3d');
  if(bundle.bakes&&Object.keys(bundle.bakes).length)features.add('bake.temporal.3d');
  if(bundle.sampledFields?.operations.length){features.add('field.sampled.3d');features.add('mesh.triangles.3d');}
  if(bundle.sampledFields?.operations.some(o=>o.attributes.length))features.add('attribute.mesh.3d');
  if(bundle.fieldVisualization?.operations.length){features.add('field.visualization.3d');features.add('mesh.triangles.3d');}
  if(bundle.fieldVisualization?.operations.some(o=>o.color))features.add('attribute.mesh.3d');
  if(bundle.fieldVisualization?.operations.some(o=>o.displacement))features.add('field.normal-displacement.3d');
  if(bundle.fieldVisualization?.operations.some(o=>o.arrows)){features.add('field.vector-arrows.3d');features.add('instance.mesh.3d');}
  if(bundle.instances?.operations.length){features.add('instance.mesh.3d');features.add('mesh.triangles.3d');}
  if(bundle.instances?.operations.some(o=>o.realize))features.add('instance.realize.3d');
  if(bundle.instances?.operations.some(o=>o.realize?.instanceColorAttribute||o.realize?.instanceSelectionAttribute))features.add('attribute.mesh.3d');
  for (const track of bundle.tracks) {
    if (track.property.startsWith('arrows.')) features.add('path.arrowheads');
    if (track.property.startsWith('transform.')) features.add('transform.affine.2d');
    if (['style.opacity', 'style.fillOpacity', 'style.strokeOpacity'].includes(track.property)) features.add('paint.opacity');
  }
  for (const binding of [...(bundle.operationGraph?.bindings ?? []),...(bundle.expressions?.bindings ?? []),...(bundle.fields?.bindings ?? [])]) {
    if (binding.property.startsWith('arrows.')) features.add('path.arrowheads');
    if (binding.property === 'transform' || binding.property.startsWith('transform.')) features.add('transform.affine.2d');
    if (['style.opacity','style.fillOpacity','style.strokeOpacity'].includes(binding.property)) features.add('paint.opacity');
  }
  return [...features].sort();
}
